#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  // Cần ít nhất: trace <mask> <lệnh>
  if(argc < 3 || argv[1][0] < '0' || argv[1][0] > '9'){
    fprintf(2, "Usage: %s mask command [args...]\n", argv[0]);
    exit(1);
  }

  // 1) Bật tracing cho CHÍNH tiến trình này với mask = argv[1]
  if(trace(atoi(argv[1])) < 0){
    fprintf(2, "%s: trace failed\n", argv[0]);
    exit(1);
  }

  // 2) Thay tiến trình này bằng chương trình argv[2] với tham số argv[2], argv[3], ...
  //    &argv[2] là mảng chuỗi kết thúc bằng 0 (vì argv[argc] == 0).
  exec(argv[2], &argv[2]);

  // exec chỉ quay lại đây nếu bị lỗi (vd: không tìm thấy chương trình)
  fprintf(2, "%s: exec %s failed\n", argv[0], argv[2]);
  exit(1);
}